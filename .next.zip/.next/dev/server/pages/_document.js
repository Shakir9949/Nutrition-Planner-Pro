var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/node_modules_186c80ea._.js")
R.c("server/chunks/ssr/[root-of-the-server]__9f350845._.js")
R.m("[project]/pages/_document.tsx [ssr] (ecmascript)")
module.exports=R.m("[project]/pages/_document.tsx [ssr] (ecmascript)").exports
